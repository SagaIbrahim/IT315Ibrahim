//
//  ViewController.swift
//  IbrahimDYM
//
//  Created by user213711 on 10/27/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblReservation: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblDateName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var imgDateImage: UIImageView!
    var DateObjects = [Date]()
    
    func InitializeDates() {
        let d1 = Date()
        d1.DateName = "Cook With Your Boo"
        d1.DateDescription = "Even if you're not much of a cook, trying out a new dish can result in lots of laughs. Not to mention, you get to eat the results"
        d1.DatePrice = "$50.00"
        d1.DateReservation = "No"
        d1.DateDuration = "Varies"
        d1.DateLocation = "At home"
        DateObjects.append(d1)
        
        
        let d2 = Date()
        d2.DateName = "Movie Drive-in"
        d2.DateDescription = "Many drive-ins still play double features, so you get twice the films for your buck. Besides, it's delightfully retro."
        d2.DatePrice = "$65.00"
        d2.DateReservation = "Yes"
        d2.DateDuration = "varies"
        d2.DateLocation = "Based on location"
        DateObjects.append(d2)
        
        let d3 = Date()
        d3.DateName = "Put together a puzzle"
        d3.DateDescription = "Ther's something so satisfying about finally clicking that last piece into place, plus it's good for the ol'noodle. "
        d3.DatePrice = "$15.00"
        d3.DateReservation = "No"
        d3.DateDuration = "Varies"
        d3.DateLocation = "At home"
        DateObjects.append(d3)
        
        let d4 = Date()
        d4.DateName = "In door sky-diving"
        d4.DateDescription = "Discover indoor skydiving and experience the same rush as tandem skydiving! Skydiving is all about the freefall – and indoor skydiving gives you that pure adrenaline rush for the entire length of the experience."
        d4.DatePrice = "$200.00"
        d4.DateReservation = "Yes"
        d4.DateDuration = "1 hour"
        d4.DateLocation = "Based on location"
        DateObjects.append(d4)
        
        let d5 = Date()
        d5.DateName = "Take a hike"
        d5.DateDescription = "Something about exploring nature with your main squeeze really gets the heart going in other way, if you know what we mean."
        d5.DatePrice = "FREE"
        d5.DateReservation = "No"
        d5.DateDuration = "Varies"
        d5.DateLocation = "Nearby Trails"
        d5.DateImage = "hike.jpeg"
        DateObjects.append(d5)
        
        let d6 = Date()
        d6.DateName = "Have a spa night"
        d6.DateDescription = "Hit up the drugstore for face masks, mani-pedi suppplies and massage oil for a DIY pampering sesh that will improve your bond and your skin."
        d6.DatePrice = "$30.00"
        d6.DateReservation = "No"
        d6.DateDuration = "1 hour"
        d6.DateLocation = "At home"
        DateObjects.append(d6)
        
        
    }
    
    func SetLables() {
        let randomHT = DateObjects.randomElement()
        lblDateName.text = randomHT?.DateName
        txtDescription.text = randomHT?.DateDescription
        lblPrice.text = randomHT?.DatePrice
        lblReservation.text = randomHT?.DateReservation
        lblDuration.text = randomHT?.DateDuration
        lblLocation.text = randomHT?.DateLocation
        imgDateImage.image = UIImage(named: randomHT!.DateImage)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        InitializeDates()
        SetLables()
        
    }
    

    
    
    @IBAction func tchNextDate(_ sender: Any) {
        SetLables()
    }
    
}

